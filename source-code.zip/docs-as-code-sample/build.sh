#!/usr/bin/env bash
set -eou pipefail

cd "`dirname "$0"`"

source ./.env 2> /dev/null ||
  source ./.env.sample

ENVIRONMENT=${ENVIRONMENT:-production}
URI_BASE=${URI_BASE:-http://localhost:1234}
zip=source-code.zip
zip2=my-answers.zip
tar=source-code.tar.gz

commit=$(git rev-parse --short HEAD 2> /dev/null || echo -n SNAPSHOT)
attrs="
  -a project=\$project
  -a commit=\$commit
  -a version=\$version
  -a recruiter=\"\$recruiter\"
  -a doctitle=\"\$doctitle\"
  -a confidential=\"\$confidential\"
"
! [ "$ENVIRONMENT" = development ] || {
  echo Building for development environment ...
  attrs="$attrs -a development -a uri-base=$URI_BASE"
}

file=README.adoc
! [ "${1:-}" = public ] || { 
  file=README.$1.adoc
  [ -f $file ] || exit
}

build() {
  echo Building \"$version\" version ...
  for tool in asciidoctor asciidoctor-pdf
  do
    eval $tool $attrs $file
  done
}

op=${1:-zip}
case "$op" in
  clean)
    git clean -fdX
    ;;
  public)
    build
    d=build/public
    mkdir -p $d
    mv README.public.html $d/index.html
    mv README.public.pdf $d/README.pdf
    ! [ -f env ] || {
      mv env .env
      rm -f README.$1.adoc
    }
    ;;
  my_answers)
    my_answers=true $0 zip
    ;;
  zip|tar)
    $0 build
    only_sources=${only_sources:-true}
    my_answers=${my_answers:-false}
    ! $my_answers || {
      echo Building $PWD/build/$zip2 ...
      zip -q build/$zip2.zip README.{html,pdf}
      exit
    }
    mkdir -p build/$project
    rsync -a \
      --exclude .git \
      --exclude build \
      --exclude private \
      . build/$project
    ! $only_sources || (
      cd build/$project
      rm -f .env *.{html,pdf}
    )
    cd build
    if [ "$op" == zip ]
    then
      rm -f $zip
      echo Building $PWD/$zip
      zip -q -r $zip $project
    else
      rm -f $tar
      echo Building $PWD/$tar
      tar -cz -f $tar $project 
    fi
    rm -rf $project
    ;;
  gh-pages)
    $0 zip
    dry_run=${dry_run:-true}
    gh_pages=build/gh-pages
    public=build/public
    mkdir -p $public
    sed "s/project/$project/g" gh-pages/README.adoc > $public/README.adoc
    cp build/source-code.zip $public/
    rsync -a $public/ $gh_pages/
    cd $gh_pages
    msg="Published at `date --rfc-3339=seconds`"
    shift
    if ! $dry_run && [ "$ENVIRONMENT" = production ]
    then
      git init
      git add -A
      git commit -m "$msg"
      git push --force $public_repo main:gh-pages
    fi
    echo $msg
    tree
    echo The directory listed above is \"$PWD\" ...
    ;;
  build)
    build
    ! [ -f .env ] || {
      mv .env env
      ln -s README.adoc README.public.adoc
    }
    $0 public
    ;;
  *)
    echo \"$1\" is an invalid option!
esac
